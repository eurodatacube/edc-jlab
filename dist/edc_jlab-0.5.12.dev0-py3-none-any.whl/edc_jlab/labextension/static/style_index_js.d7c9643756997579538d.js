(self["webpackChunkedc_jlab"] = self["webpackChunkedc_jlab"] || []).push([["style_index_js"],{

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _images_EDC_logo_square_blue_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./images/EDC_logo_square_blue.svg */ "./style/images/EDC_logo_square_blue.svg");
/* harmony import */ var _images_EDC_logo_square_blue_svg__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_images_EDC_logo_square_blue_svg__WEBPACK_IMPORTED_MODULE_3__);
// Imports




var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()((_images_EDC_logo_square_blue_svg__WEBPACK_IMPORTED_MODULE_3___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/*\n * Author: Bernhard Mallinger\n * Copyright (c) EOX IT Services\n * Distributed under the terms of the MIT License.\n */\n\n.edc-toolbar {\n  height: auto !important;\n  padding: 10px;\n}\n\n.edc-toolbar button {\n  background-color: #004170 !important;\n  height: 40px;\n  padding: 0;\n}\n\n.edc-toolbar .bp3-button-text {\n  display: flex;\n  height: 100%;\n  align-items: center;\n  padding: 10px 16px;\n}\n\n.edc-toolbar .jp-ToolbarButtonComponent-icon {\n  color: #fff;\n  margin: 2px 4px 0 0;\n}\n\n.edc-toolbar .jp-ToolbarButtonComponent-label {\n  color: #fff !important;\n  font-size: 1rem !important;\n}\n\n.notebook-catalog-icon {\n   background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");\n}\n\n\n/* we need this more specific selector because the section icon is the first command icon,\n * which we don't want */\n.jp-LauncherCard-icon .readme-icon {\n    /* actual readme */\n    background-image: url('https://cockpit.hub.eox.at/storage/uploads/eoxhub/readme.svg');\n    background-size: contain;\n}\n\n.jp-Launcher-sectionHeader .readme-icon {\n    /* section header, not readme */\n    background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");\n}\n\n.catalog-icon {\n    /* catalog is not used as section header, so no tricks here */\n    background-image: url('https://cockpit.hub.eox.at/storage/uploads/eoxhub/catalog.svg');\n    background-size: contain;\n}\n", "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;EAIE;;AAEF;EACE,uBAAuB;EACvB,aAAa;AACf;;AAEA;EACE,oCAAoC;EACpC,YAAY;EACZ,UAAU;AACZ;;AAEA;EACE,aAAa;EACb,YAAY;EACZ,mBAAmB;EACnB,kBAAkB;AACpB;;AAEA;EACE,WAAW;EACX,mBAAmB;AACrB;;AAEA;EACE,sBAAsB;EACtB,0BAA0B;AAC5B;;AAEA;GACG,yDAAwD;AAC3D;;;AAGA;wBACwB;AACxB;IACI,kBAAkB;IAClB,qFAAqF;IACrF,wBAAwB;AAC5B;;AAEA;IACI,+BAA+B;IAC/B,yDAAwD;AAC5D;;AAEA;IACI,6DAA6D;IAC7D,sFAAsF;IACtF,wBAAwB;AAC5B","sourcesContent":["/*\n * Author: Bernhard Mallinger\n * Copyright (c) EOX IT Services\n * Distributed under the terms of the MIT License.\n */\n\n.edc-toolbar {\n  height: auto !important;\n  padding: 10px;\n}\n\n.edc-toolbar button {\n  background-color: #004170 !important;\n  height: 40px;\n  padding: 0;\n}\n\n.edc-toolbar .bp3-button-text {\n  display: flex;\n  height: 100%;\n  align-items: center;\n  padding: 10px 16px;\n}\n\n.edc-toolbar .jp-ToolbarButtonComponent-icon {\n  color: #fff;\n  margin: 2px 4px 0 0;\n}\n\n.edc-toolbar .jp-ToolbarButtonComponent-label {\n  color: #fff !important;\n  font-size: 1rem !important;\n}\n\n.notebook-catalog-icon {\n   background-image: url('images/EDC_logo_square_blue.svg');\n}\n\n\n/* we need this more specific selector because the section icon is the first command icon,\n * which we don't want */\n.jp-LauncherCard-icon .readme-icon {\n    /* actual readme */\n    background-image: url('https://cockpit.hub.eox.at/storage/uploads/eoxhub/readme.svg');\n    background-size: contain;\n}\n\n.jp-Launcher-sectionHeader .readme-icon {\n    /* section header, not readme */\n    background-image: url('images/EDC_logo_square_blue.svg');\n}\n\n.catalog-icon {\n    /* catalog is not used as section header, so no tricks here */\n    background-image: url('https://cockpit.hub.eox.at/storage/uploads/eoxhub/catalog.svg');\n    background-size: contain;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./style/images/EDC_logo_square_blue.svg":
/*!***********************************************!*\
  !*** ./style/images/EDC_logo_square_blue.svg ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml,%3C!DOCTYPE svg PUBLIC '-//W3C//DTD SVG 1.1//EN' 'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd'%3E%3Csvg width='100%25' height='100%25' viewBox='0 0 800 800' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' xml:space='preserve' xmlns:serif='http://www.serif.com/' style='fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:1.41421;'%3E%3Crect id='light' x='0' y='0' width='800' height='800' style='fill:none;'/%3E%3Cg id='light1' serif:id='light'%3E%3Cg%3E%3Cpath d='M615.701,615.701l0,-431.402l-431.402,0l0,78.485l-26.415,0l0,-104.9l484.232,0l0,484.232l-484.232,0l0,-90.674l26.415,0l0,64.259l431.402,0Z' style='fill:%23004170;'/%3E%3Cg%3E%3Cpath d='M563.672,426.326c-1.515,16.098 -7.458,28.661 -17.823,37.673c-10.364,9.02 -24.154,13.526 -41.355,13.526c-12.027,0 -22.616,-2.851 -31.769,-8.546c-9.152,-5.703 -16.222,-13.806 -21.194,-24.31c-4.98,-10.504 -7.567,-22.702 -7.777,-36.585l0,-14.101c0,-14.233 2.525,-26.773 7.567,-37.619c5.042,-10.853 12.283,-19.213 21.715,-25.087c9.432,-5.873 20.332,-8.81 32.701,-8.81c16.649,0 30.059,4.514 40.213,13.526c10.163,9.02 16.067,21.785 17.722,38.303l-26.112,0c-1.251,-10.854 -4.406,-18.678 -9.487,-23.479c-5.081,-4.801 -12.524,-7.202 -22.336,-7.202c-11.405,0 -20.161,4.164 -26.276,12.501c-6.114,8.336 -9.237,20.557 -9.377,36.67l0,13.387c0,16.323 2.921,28.769 8.756,37.346c5.842,8.578 14.388,12.866 25.654,12.866c10.294,0 18.032,-2.315 23.214,-6.946c5.182,-4.63 8.469,-12.337 9.852,-23.113l26.112,0Z' style='fill:%23004170;fill-rule:nonzero;'/%3E%3Cpath d='M246.088,408.084l-61.983,0l0,46.429l72.448,0l0,20.938l-98.669,0l0,-150.91l97.946,0l0,21.148l-71.725,0l0,41.667l61.983,0l0,20.728Z' style='fill:%23004170;fill-rule:nonzero;'/%3E%3Cpath d='M293.873,475.451l0,-150.91l44.565,0c13.339,0 25.172,2.976 35.497,8.912c10.333,5.943 18.328,14.373 23.999,25.296c5.664,10.916 8.5,23.425 8.5,37.518l0,7.567c0,14.303 -2.852,26.882 -8.554,37.727c-5.703,10.846 -13.822,19.206 -24.357,25.079c-10.535,5.874 -22.616,8.811 -36.228,8.811l-43.422,0Zm26.221,-129.762l0,108.824l17.1,0c13.752,0 24.303,-4.297 31.668,-12.897c7.357,-8.608 11.102,-20.954 11.242,-37.059l0,-8.391c0,-16.378 -3.558,-28.886 -10.675,-37.525c-7.117,-8.632 -17.45,-12.952 -30.991,-12.952l-18.344,0Z' style='fill:%23004170;fill-rule:nonzero;'/%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E"

/***/ }),

/***/ "./style/index.js":
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");



/***/ })

}]);
//# sourceMappingURL=style_index_js.d7c9643756997579538d.js.map