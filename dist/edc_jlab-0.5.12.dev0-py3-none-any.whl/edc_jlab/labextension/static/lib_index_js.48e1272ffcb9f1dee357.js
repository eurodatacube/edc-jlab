(self["webpackChunkedc_jlab"] = self["webpackChunkedc_jlab"] || []).push([["lib_index_js"],{

/***/ "./lib/constants.js":
/*!**************************!*\
  !*** ./lib/constants.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NOTEBOOK_ICON_CLASS": () => (/* binding */ NOTEBOOK_ICON_CLASS),
/* harmony export */   "EURODATACUBE_CATALOG": () => (/* binding */ EURODATACUBE_CATALOG)
/* harmony export */ });
// Author: Bernhard Mallinger
// Copyright (c) EOX IT Services
// Distributed under the terms of the MIT License.
const NOTEBOOK_ICON_CLASS = "notebook-catalog-icon";
const EURODATACUBE_CATALOG = "eurodatacube";


/***/ }),

/***/ "./lib/contestSubmit.js":
/*!******************************!*\
  !*** ./lib/contestSubmit.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "activateContestSubmit": () => (/* binding */ activateContestSubmit)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./lib/constants.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
// Author: Bernhard Mallinger
// Copyright (c) EOX IT Services
// Distributed under the terms of the MIT License.




/**
 * Add a context menu entry which triggers contest submission
 */
function activateContestSubmit(app, factory, contestName) {
    const commandId = "edc:contest-submit";
    app.commands.addCommand(commandId, {
        label: `EDC: Submit directory for ${contestName}`,
        iconClass: _constants__WEBPACK_IMPORTED_MODULE_2__.NOTEBOOK_ICON_CLASS,
        isVisible: () => {
            const filebrowser = factory.tracker.currentWidget;
            if (!filebrowser) {
                return false;
            }
            const files = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_1__.toArray)(filebrowser.selectedItems());
            if (files.length !== 1) {
                return false;
            }
            return files[0].type === "directory";
        },
        execute: async () => {
            const filebrowser = factory.tracker.currentWidget;
            if (!filebrowser) {
                return;
            }
            const items = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_1__.toArray)(filebrowser.selectedItems());
            if (items.length === 1) {
                const path = items[0].path;
                console.log("Contest submit directory:", path);
                const result = await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                    title: `Submission for ${contestName}`,
                    body: `Do you really want to submit ${path} for ${contestName}?`,
                    buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.cancelButton(), _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton()]
                });
                if (result.button.accept) {
                    await doSubmit(path);
                }
            }
            else {
                console.error("Submit called with bad number of dirs", items);
            }
            ;
        }
    });
    // selector as from packages/filebrowser-extension/src/index.ts
    const selectorNotDir = '.jp-DirListing-item[data-isdir="true"]';
    app.contextMenu.addItem({
        selector: selectorNotDir,
        command: commandId,
        rank: 9,
    });
    async function doSubmit(path) {
        try {
            await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('contest_submit', {
                body: JSON.stringify({ directory: path }),
                method: "POST",
            });
            (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                title: "Contest submission successful",
                body: "Your contest entry has been submitted successfully!",
                buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton()],
            });
        }
        catch (e) {
            console.log("error:", e);
            (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)("Contest submit failed", `Failed to submit directory for contest: ${e}`);
        }
    }
}
;


/***/ }),

/***/ "./lib/contribute.js":
/*!***************************!*\
  !*** ./lib/contribute.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "activateContribute": () => (/* binding */ activateContribute)
/* harmony export */ });
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "./lib/constants.js");
// Author: Bernhard Mallinger
// Copyright (c) EOX IT Services
// Distributed under the terms of the MIT License.


/**
 * Add a context menu entry which triggers contributions
 */
function activateContribute(app, docmanager, factory) {
    const contributeCommandId = "edc:contribute";
    app.commands.addCommand(contributeCommandId, {
        label: "EDC: Contribute Notebook",
        iconClass: _constants__WEBPACK_IMPORTED_MODULE_1__.NOTEBOOK_ICON_CLASS,
        isVisible: () => {
            // NOTE: market place is currently restricted to 1 contributed file
            const filebrowser = factory.tracker.currentWidget;
            if (!filebrowser) {
                return false;
            }
            const files = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__.toArray)(filebrowser.selectedItems());
            if (files.length !== 1) {
                return false;
            }
            return files[0].type === "notebook";
        },
        execute: () => {
            const filebrowser = factory.tracker.currentWidget;
            if (!filebrowser) {
                return;
            }
            const items = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__.toArray)(filebrowser.selectedItems());
            console.log("Contribute items:", items.map((item) => item.path).join(", "));
            if (items.length > 0) {
                // TODO: make call to new backend endpoint (TODO) to copy the files to .contribute-staging
                const contributePromise = null;
                // need to open window right now in click handler, it's not allowed
                // in promise handler.
                const newTab = window.open("", "_blank");
                contributePromise.then(() => {
                    // TODO: open according contribute page (dev/prod)
                    // NOTE: market place is currently restricted to 1 contributed file
                    newTab.location.href = `https://eurodatacube.com/contributions/jupyter-notebook/new/${items[0].name}`;
                })
                    .catch(() => {
                    newTab.close();
                    alert("Failed to contribute files.");
                });
            }
        },
    });
    // selector as from packages/filebrowser-extension/src/index.ts
    const selectorNotDir = '.jp-DirListing-item[data-isdir="false"]';
    app.contextMenu.addItem({
        selector: selectorNotDir,
        command: contributeCommandId,
        rank: 9,
    });
}


/***/ }),

/***/ "./lib/copyByRouter.js":
/*!*****************************!*\
  !*** ./lib/copyByRouter.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "activateCopyByRouter": () => (/* binding */ activateCopyByRouter),
/* harmony export */   "parseCopyUrlParam": () => (/* binding */ parseCopyUrlParam)
/* harmony export */ });
/* harmony import */ var _notebookCatalog__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notebookCatalog */ "./lib/notebookCatalog.js");
// Author: Bernhard Mallinger
// Copyright (c) EOX IT Services
// Distributed under the terms of the MIT License.

/**
 * Enables copying files to the workspace by visiting the url:
 *
 * /lab?copy=/my-notebook.ipynb
 *
 */
function activateCopyByRouter(app, docmanager, router) {
    const copyNotebookFromRouterCommandName = "edc:copyNotebookFromRouter";
    router.register({
        command: copyNotebookFromRouterCommandName,
        pattern: /(\?copy=|&copy=)([^?]+)/,
    });
    app.commands.addCommand(copyNotebookFromRouterCommandName, {
        execute: (args) => {
            console.log("Copy notebook from args: ", args, args.search);
            const path = parseCopyUrlParam(args.search);
            if (path) {
                return (0,_notebookCatalog__WEBPACK_IMPORTED_MODULE_0__.deployNotebook)(docmanager, path);
            }
        },
    });
}
function parseCopyUrlParam(search) {
    const urlParams = new URLSearchParams(search);
    if (urlParams.has("reset")) {
        console.log("Url is being reset, not triggering copy");
        return null;
    }
    else {
        const path = urlParams.get("copy");
        console.log("Parsed URL parameters:", urlParams.toString(), path);
        return path;
    }
}


/***/ }),

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "requestAPI": () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'edc_jlab', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/docmanager */ "webpack/sharing/consume/default/@jupyterlab/docmanager");
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/mainmenu */ "webpack/sharing/consume/default/@jupyterlab/mainmenu");
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _versionLink__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./versionLink */ "./lib/versionLink.js");
/* harmony import */ var _contribute__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./contribute */ "./lib/contribute.js");
/* harmony import */ var _notebookCatalog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./notebookCatalog */ "./lib/notebookCatalog.js");
/* harmony import */ var _copyByRouter__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./copyByRouter */ "./lib/copyByRouter.js");
/* harmony import */ var _contestSubmit__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./contestSubmit */ "./lib/contestSubmit.js");
/* harmony import */ var _stacDownload__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./stacDownload */ "./lib/stacDownload.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./constants */ "./lib/constants.js");
// Author: Bernhard Mallinger
// Copyright (c) EOX IT Services
// Distributed under the terms of the MIT License.













/**
 * Initialization data for the edc-jlab extension.
 */
const extension = {
    id: "edc-jlab",
    autoStart: true,
    requires: [
        _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_1__.ILauncher,
        _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2__.IDocumentManager,
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.IRouter,
        _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_3__.IFileBrowserFactory,
        _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_4__.IMainMenu,
    ],
    activate: async (app, launcher, docmanager, router, factory, mainMenu) => {
        const { name: catalogName, url: catalogUrl } = await (0,_handler__WEBPACK_IMPORTED_MODULE_5__.requestAPI)('catalog');
        (0,_notebookCatalog__WEBPACK_IMPORTED_MODULE_6__.activateNotebookCatalog)(app, docmanager, launcher, catalogName, catalogUrl);
        (0,_versionLink__WEBPACK_IMPORTED_MODULE_7__.activateVersionLink)(app, docmanager, mainMenu);
        (0,_copyByRouter__WEBPACK_IMPORTED_MODULE_8__.activateCopyByRouter)(app, docmanager, router);
        (0,_contribute__WEBPACK_IMPORTED_MODULE_9__.activateContribute)(app, docmanager, factory);
        (0,_stacDownload__WEBPACK_IMPORTED_MODULE_10__.activateStacDownload)(app, docmanager, factory);
        if (catalogName != _constants__WEBPACK_IMPORTED_MODULE_11__.EURODATACUBE_CATALOG) {
            (0,_contestSubmit__WEBPACK_IMPORTED_MODULE_12__.activateContestSubmit)(app, factory, catalogName);
        }
        // we set the domain to the last 2 domain parts to be able to communicate with
        // the child frame
        // this code would not work for domains with 3 dots such as a.co.uk.
        document.domain = document.location.hostname.split(".").slice(-2).join(".");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ }),

/***/ "./lib/notebookCatalog.js":
/*!********************************!*\
  !*** ./lib/notebookCatalog.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "deployNotebook": () => (/* binding */ deployNotebook),
/* harmony export */   "activateNotebookCatalog": () => (/* binding */ activateNotebookCatalog)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./lib/constants.js");
// Author: Bernhard Mallinger
// Copyright (c) EOX IT Services
// Distributed under the terms of the MIT License.



function getNotebookUrlFromIFrameEvent(event) {
    const newPathname = event.target.contentWindow.location
        .pathname;
    // pathname is something like /notebooks/a/b/c/nb.ipynb
    const prefix = "/notebooks";
    if (!newPathname.startsWith(prefix)) {
        console.warn(`Ignoring new iframe url ${newPathname}`);
        return null;
    }
    // NOTE: nbviewer url path and notebook path are the same, but this is an accident!
    //       nbviewer uses "/notebooks" as url prefix to serve local files. But also
    //       the main directory of the notebooks is called "notebooks", and nbviewer
    //       services files directly from this directory.
    return newPathname;
}
function isNotebookFile(nbPath) {
    return nbPath.endsWith(".ipynb");
}
function createToolbar(docmanager) {
    const toolbar = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Toolbar();
    toolbar.addClass("edc-toolbar");
    let toolbarCopyButton = null;
    function refreshToolbar(currentNbPath) {
        // there doesn't seem to be a way to toggle "enable", so we re-add the button
        // every time.
        if (toolbarCopyButton) {
            toolbar.layout.removeWidget(toolbarCopyButton);
        }
        const enabled = isNotebookFile(currentNbPath);
        toolbarCopyButton = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ToolbarButton({
            label: "Execute Notebook",
            iconClass: "fa fa-download",
            enabled: enabled,
            tooltip: enabled
                ? "Execute notebook to home directory and open it"
                : "Select a notebook to execute",
            onClick: () => deployNotebook(docmanager, currentNbPath),
        });
        toolbar.addItem("copy", toolbarCopyButton);
    }
    refreshToolbar("");
    return { toolbar, refreshToolbar };
}
class HtmlLabelRenderer extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.Renderer {
    createBody(value) {
        const label = value.node.querySelector("label");
        // show html as html
        label.innerHTML = label.innerText;
        return super.createBody(value);
    }
}
/**
 * Ask user about path and copies notebook there
 */
async function deployNotebook(docmanager, nbPath) {
    // suggest just the filename since it doesn't seem easy to create directories here
    // and also the users probably don't want to mirror the notebook repo dir structure.
    const suggestedPath = nbPath.substring(nbPath.lastIndexOf("/") + 1);
    const selectLabel = `Select a filename for the notebook "${suggestedPath}":`;
    let label = selectLabel;
    // repeat input in case of problems
    let bailout = false;
    while (!bailout) {
        const res = await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getText({
            text: suggestedPath,
            title: "Copy notebook to workspace",
            renderer: new HtmlLabelRenderer(),
            label,
        });
        if (!res.button.accept) {
            bailout = true;
        }
        else {
            const targetPath = res.value;
            try {
                await (0,_handler__WEBPACK_IMPORTED_MODULE_1__.requestAPI)('install_notebook', {
                    body: JSON.stringify({
                        nbPath: nbPath,
                        targetPath: targetPath,
                    }),
                    method: "POST",
                });
                docmanager.open(targetPath);
                bailout = true;
            }
            catch (e) {
                console.log("error:", e);
                if (e.response && e.response.status === 409) {
                    // ok, file exists
                }
                else {
                    throw e;
                }
            }
            if (!bailout) {
                label = `<p><b>Saving failed: existing or wrong filename</b></p>
                <p>If the file "${targetPath}" already exists, you can access it in the filebrowser on the left side of the screen.</p>
                ${selectLabel}`;
            }
        }
    }
}
function createWidget(docmanager, catalogUrl) {
    const iframe = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.IFrame();
    iframe.url = catalogUrl;
    const { toolbar, refreshToolbar } = createToolbar(docmanager);
    const iframeDomElem = iframe.node.querySelector("iframe");
    iframeDomElem.addEventListener("load", (event) => {
        const nbPath = getNotebookUrlFromIFrameEvent(event);
        refreshToolbar(nbPath);
    });
    // We need cross domain iframe communication, so we have to
    // remove the sandboxing :-(. However we only load the iframe from our
    // domain, so it you'd have to hack the domain anyway to do damage. Also
    // the nbviewer has a very small attack surface.
    iframeDomElem.removeAttribute("sandbox");
    return new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget({
        content: iframe,
        toolbar,
    });
}
/**
 * Add a notebook catalog accessible via launcher icon. Shows notebooks in an own
 * tab with an nbviewer iframe and a copy button.
 */
function activateNotebookCatalog(app, docmanager, launcher, catalogName, catalogUrl) {
    const category = "EOxHub";
    function createCommand(id, label, url, iconClass) {
        let notebookCatalogWidget = null;
        const catalogCommandName = `edc:notebook_catalog_${id}`;
        app.commands.addCommand(catalogCommandName, {
            label,
            iconClass,
            execute: () => {
                if (!notebookCatalogWidget || !notebookCatalogWidget.isAttached) {
                    // it would be nicer to keep the widget instance, but it seems that
                    // detaching destroys the layout object of the toolbar :-/
                    notebookCatalogWidget = createWidget(docmanager, url);
                    notebookCatalogWidget.title.label = label;
                    notebookCatalogWidget.title.iconClass = iconClass;
                    notebookCatalogWidget.title.closable = true;
                    app.shell.add(notebookCatalogWidget, "main");
                }
                app.shell.activateById(notebookCatalogWidget.id);
            },
        });
        return catalogCommandName;
    }
    const catalogNotebooksBaseUrl = `${catalogUrl}/${catalogName}/notebooks`;
    launcher.add({
        category,
        command: createCommand("readme", catalogName, `${catalogNotebooksBaseUrl}/README.ipynb`, "readme-icon"),
        rank: 0,
    });
    launcher.add({
        category,
        command: createCommand("catalog", catalogName, catalogNotebooksBaseUrl, "catalog-icon"),
        rank: 1,
    });
    if (catalogName != _constants__WEBPACK_IMPORTED_MODULE_2__.EURODATACUBE_CATALOG) {
        launcher.add({
            category,
            command: createCommand("eurodatacube", _constants__WEBPACK_IMPORTED_MODULE_2__.EURODATACUBE_CATALOG, `${catalogUrl}/${_constants__WEBPACK_IMPORTED_MODULE_2__.EURODATACUBE_CATALOG}/notebooks`, "catalog-icon"),
            rank: 2,
        });
    }
}


/***/ }),

/***/ "./lib/stacDownload.js":
/*!*****************************!*\
  !*** ./lib/stacDownload.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "activateStacDownload": () => (/* binding */ activateStacDownload)
/* harmony export */ });
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/algorithm */ "webpack/sharing/consume/default/@lumino/algorithm");
/* harmony import */ var _lumino_algorithm__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants */ "./lib/constants.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
// Author: Bernhard Mallinger
// Copyright (c) EOX IT Services
// Distributed under the terms of the MIT License.




// TODO: get rid of "download" wording everywhere
/**
 * Add a context menu triggering stac item download
 */
function activateStacDownload(app, docmanager, factory) {
    const downloadCommand = "eoxhub:stac-download";
    app.commands.addCommand(downloadCommand, {
        label: "EOxHub: Generate STAC processing notebook",
        iconClass: _constants__WEBPACK_IMPORTED_MODULE_2__.NOTEBOOK_ICON_CLASS,
        isVisible: () => {
            // NOTE: market place is currently restricted to 1 contributed file
            const filebrowser = factory.tracker.currentWidget;
            if (!filebrowser) {
                return false;
            }
            const files = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__.toArray)(filebrowser.selectedItems());
            if (files.length !== 1) {
                // limit to 1 file for now
                return false;
            }
            // allow operation or all json files
            return files[0].mimetype == "application/json";
        },
        execute: async () => {
            const filebrowser = factory.tracker.currentWidget;
            if (!filebrowser) {
                return;
            }
            const items = (0,_lumino_algorithm__WEBPACK_IMPORTED_MODULE_0__.toArray)(filebrowser.selectedItems());
            console.log("downloading items:", items.map((item) => item.path).join(", "));
            if (items.length > 0) {
                const nbPath = await doDownloadStacItem(items[0].path);
                docmanager.open(nbPath);
            }
        },
    });
    // selector as from packages/filebrowser-extension/src/index.ts
    const selectorNotDir = '.jp-DirListing-item[data-isdir="false"]';
    app.contextMenu.addItem({
        selector: selectorNotDir,
        command: downloadCommand,
        rank: 9,
    });
}
async function doDownloadStacItem(path) {
    try {
        const response = await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('stac_item', {
            body: JSON.stringify({
                item_path: path,
            }),
            method: "POST",
        });
        return response["notebook_path"];
    }
    catch (e) {
        console.log("error:", e);
        (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)("Download failed", `Failed to download stac item: ${e}`);
        return ""; // TOOD: check what happens here
    }
}


/***/ }),

/***/ "./lib/versionLink.js":
/*!****************************!*\
  !*** ./lib/versionLink.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "activateVersionLink": () => (/* binding */ activateVersionLink)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./lib/constants.js");
// Author: Bernhard Mallinger
// Copyright (c) EOX IT Services
// Distributed under the terms of the MIT License.

function activateVersionLink(app, docmanager, mainMenu) {
    const kernelspecs = docmanager.services.kernelspecs.specs.kernelspecs;
    // use "first" kernelspec
    const kernelSpec = Object.values(kernelspecs).pop();
    // use custom version info added to base images
    const version = kernelSpec.metadata.version;
    const versionLinkCommand = "edc:goto-version";
    app.commands.addCommand(versionLinkCommand, {
        label: `Python libraries in the ${kernelSpec.display_name} Kernel`,
        iconClass: _constants__WEBPACK_IMPORTED_MODULE_0__.NOTEBOOK_ICON_CLASS,
        execute: () => {
            window.open(`https://github.com/eurodatacube/base-images/releases/tag/user-${version}`);
        },
    });
    // 21 is right below the official kernel info, which is 20
    mainMenu.helpMenu.addGroup([{ command: versionLinkCommand }], 21);
}


/***/ })

}]);
//# sourceMappingURL=lib_index_js.48e1272ffcb9f1dee357.js.map